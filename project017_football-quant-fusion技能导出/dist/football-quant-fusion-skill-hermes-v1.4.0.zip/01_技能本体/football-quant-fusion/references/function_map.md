# 函数映射档案（英文函数名 → 中文功能）

> 全局统一管理本文件：新增/修改函数时，先更新 `project006_融合引擎全功能测试/02_脚本/mapping.py`，
> 再运行 `insert_comments.py`（同步代码内注释）与 `gen_map_doc.py`（重新生成本档案），保持两处一致。

## 注释约定

- 代码内统一格式：`# [中文功能] <说明>`，放在 `def` 上方一行，缩进与 def 对齐。
- 本档案按脚本归档：`文件 → 函数 → 中文功能`。
- 覆盖范围：football-quant-fusion 融合层 + zu-yu-dashi-3 核心引擎全部 `.py` 脚本。
- 只维护注释与说明，不改变任何代码逻辑。


## backtest_selected_leagues_oos.py

| 函数名 | 中文功能 |
| --- | --- |
| `idx` | 把比分转成胜平负索引（主胜0/平1/客胜2） |
| `score` | 计算指定快照的Brier/LogLoss/命中统计 |
| `evaluate_split` | 按时间顺序切分训练/验证/测试三段样本 |
| `main` | 对选定联赛跑留出样本（OOS）回测并输出报告 |

## evaluate_selected_leagues.py

| 函数名 | 中文功能 |
| --- | --- |
| `idx` | 把比分转成胜平负索引（主胜0/平1/客胜2） |
| `brier` | 计算三元Brier分数（概率与结果的平方误差） |
| `ece` | 计算期望校准误差ECE（分10桶统计） |
| `run` | 汇总单联赛所有记录的校准与命中指标 |
| `main` | 按联赛批量评估并输出总报告 |

## fetch_sporttery_history_all.py

| 函数名 | 中文功能 |
| --- | --- |
| `atomic` | 原子写JSON（先写临时文件再替换） |
| `get` | 带重试的HTTP GET请求（体彩官方接口） |
| `days` | 生成起始到结束的日期序列 |
| `flatten` | 展平官方接口按天分组的场次列表 |
| `keep_league` | 按联赛名与关键词过滤需要保留的场次 |
| `latest_before` | 取指定时间点之前最近的一次盘口快照 |
| `odds3` | 从盘口行提取主/平/客三项赔率 |
| `fixed` | 抓取单场固定奖金与赔率历史 |
| `main` | 批量下载指定日期区间的历史数据 |
| `task` | 并发任务包装，单场异常不回传崩溃 |

## fusion_cli.py

| 函数名 | 中文功能 |
| --- | --- |
| `option_value` | 从命令行参数中提取指定flag的值 |
| `run_script` | 以子进程运行脚本并转发其输出 |
| `maybe_odds_add` | 可选项：把采集结果写入赔率移动库 |
| `record_fusion` | 融合登记主流程（预测→包裹→注册回测库） |
| `main` | CLI子命令路由入口 |

## fusion_combo.py

| 函数名 | 中文功能 |
| --- | --- |
| `load` | 按行读取registry.jsonl注册记录 |
| `main` | 校验组合腿ID的有效性并输出结果 |

## fusion_daily_pipeline.py

| 函数名 | 中文功能 |
| --- | --- |
| `run` | 带重试地执行子进程命令 |
| `main` | 每日流水线：结算→采集→登记→赔率移动 |

## fusion_predict.py

（加载器/无自定义函数）

## fusion_record.py

| 函数名 | 中文功能 |
| --- | --- |
| `parse_dt` | 解析ISO时间字符串（兼容Z后缀） |
| `main` | 把融合预测输出登记进回测注册库 |

## recommendation_policy.py

| 函数名 | 中文功能 |
| --- | --- |
| `load_policy` | 加载推荐策略配置，缺失时返回默认策略 |
| `_flags` | 汇总输出的可靠性旗标列表 |
| `_forecast` | 从输出中取核心预测对象（兼容新旧结构） |
| `_market_freshness` | 取市场新鲜度信息 |
| `_calibrated_primary` | 读取已批准的主概率校准值（未批准返回None） |
| `evaluate` | 计算推荐门控与可审计的风险详情 |
| `validate_combo_ids` | 严格校验组合腿ID（缺失/重复即无效） |

## runtime.py

| 函数名 | 中文功能 |
| --- | --- |
| `resolve_python` | 解析应使用的Python解释器（非3.12自动切换到内置3.12） |

## sales_day_collect.py

| 函数名 | 中文功能 |
| --- | --- |
| `list_matches` | 拉取某日体彩官方场次列表 |
| `run_core` | 调用核心采集器拉取单场或整日全盘口 |
| `main` | 按竞彩销售日采集并生成模型输入 |

## sample_audit.py

| 函数名 | 中文功能 |
| --- | --- |
| `load` | 按行读取registry.jsonl注册记录 |
| `main` | 按快照统计样本数、去重与可结算市场 |

## add_elo.py

| 函数名 | 中文功能 |
| --- | --- |
| `load_snapshots` | 加载ClubElo CSV快照，返回日期列表与队名Elo映射 |
| `parse_date` | 统一football-data的日期格式为YYYY-MM-DD |
| `main` | 为回测集补充ClubElo（防前视偏差） |

## analyze_sporttery_dataset.py

| 函数名 | 中文功能 |
| --- | --- |
| `mean` | 计算列表均值（空列表返回None） |
| `ll` | 计算对数损失（单样本） |
| `brier` | 计算Brier分数（单样本） |
| `binstats` | 按赔率区间分桶统计结果分布 |
| `poisson_over` | 泊松分布大球（超2.5球）概率 |
| `main` | 分析体彩历史数据集的校准指标 |
| `binary` | 计算二分类Brier/LogLoss等指标 |
| `clean` | 把输出中的非JSON类型转为可序列化结构 |

## apply_time_decay.py

| 函数名 | 中文功能 |
| --- | --- |
| `main` | 给预览强度应用时间衰减并输出新预览 |

## backtest.py

| 函数名 | 中文功能 |
| --- | --- |
| `pct` | 小数转百分数（None保持None） |
| `mean` | 计算均值（空序列返回None） |
| `bins` | 按概率分桶统计并计算ECE |
| `score_row` | 把一条登记记录转成回测评分行 |
| `load_store` | 从回测库加载注册记录与赛果 |
| `load_offline` | 加载离线历史JSON并即时预测 |
| `main` | 回测主入口（在线登记库或离线文件） |
| `av` | 取某字段所有有效值的均值 |

## backtest_lib.py

| 函数名 | 中文功能 |
| --- | --- |
| `now` | 返回当前UTC时间ISO字符串 |
| `canonical` | 生成排序键的规范JSON字符串 |
| `sha` | 计算内容SHA256哈希 |
| `slug` | 把文本转成可读ASCII短标识（附稳定哈希） |
| `atomic_json` | 原子写JSON文件 |
| `append_jsonl` | 追加一行JSON到jsonl文件 |
| `load_jsonl` | 读取jsonl文件为对象列表 |
| `brier` | 计算单样本Brier分数 |
| `logloss` | 计算单样本对数损失 |
| `binary_brier` | 计算二分类Brier分数 |
| `actual_1x2` | 由主客比分得到胜平负实际结果索引 |
| `ah_state` | 按亚洲盘线结算主队输赢/走盘状态 |
| `r` | 符号函数：正/负/零判胜负 |

## build_historical_dataset.py

| 函数名 | 中文功能 |
| --- | --- |
| `main` | 从football-data构建历史数据集 |

## build_sporttery_snapshot_dataset.py

| 函数名 | 中文功能 |
| --- | --- |
| `parse_dt` | 解析多种时间格式为datetime |
| `kickoff` | 从输入提取开球时间 |
| `valid_had` | 校验HAD盘口行是否有效 |
| `row_dt` | 取盘口行的更新时间 |
| `odds3` | 从有效行提取三项赔率 |
| `parse_score` | 把比分字符串转成(主,客)整数 |
| `snapshot_for` | 为单场抽取指定时刻附近的盘口快照 |
| `build_match` | 把原始采集行组装成训练样本 |
| `main` | 生成体彩快照数据集（JSONL） |

## build_sporttery_training_set.py

| 函数名 | 中文功能 |
| --- | --- |
| `devig` | 赔率去水，返回归一化概率与庄家边际 |
| `score90` | 优先提取常规时间比分字段 |
| `snapshot` | 取比赛临近收盘的盘口快照 |
| `ttg_probs` | 由TTG赔率转8档总进球概率 |
| `crs_top` | 取CRS赔率最低的Top比分 |
| `main` | 把采集数据加工成训练集 |

## daily_pipeline.py

| 函数名 | 中文功能 |
| --- | --- |
| `run` | 带重试地执行子进程命令 |
| `main` | 核心版每日流水线（结算→采集→登记） |

## daily_snapshot.py

| 函数名 | 中文功能 |
| --- | --- |
| `main` | 生成某日全部场次的快照数据集 |

## fd_to_backtest.py

| 函数名 | 中文功能 |
| --- | --- |
| `pick_odds` | 按优先级取一组完整赔率，缺失则降级下一来源 |
| `convert` | 把football-data CSV转换为回测JSON |
| `main` | CLI入口：CSV列表转回测数据集 |

## fetch_match_preview.py

| 函数名 | 中文功能 |
| --- | --- |
| `fetch` | 带重试地请求体彩官方前瞻接口 |
| `fnum` | 安全转float（失败返回默认值） |
| `build_strength` | 由近N场攻防均值交叉生成λ锚 |
| `collect` | 采集单场特征、交锋、近期、伤停、积分、赛程 |
| `main` | 按matchId或采集文件批量生成前瞻JSON |
| `side_matches` | 提取主/客队一方的近期赛程 |
| `injuries` | 按位置与出场率折算攻防门三档缺阵冲击 |

## fetch_sporttery_full.py

| 函数名 | 中文功能 |
| --- | --- |
| `fetch` | 请求体彩官方接口并解析JSON |
| `num` | 安全转float（失败返回None） |
| `latest` | 取盘口历史最后一行 |
| `stamp` | 拼装盘口更新时间戳 |
| `parse_crs` | 解析比分玩法CRS赔率 |
| `parse_ttg` | 解析总进球TTG 8档赔率 |
| `parse_hafu` | 解析半全场HAFU九宫格赔率 |
| `parse_list` | 展平官方按天分组的场次列表 |
| `parse_results` | 从赛程列表提取赛果（半场/全场比分） |
| `to_input` | 把原始采集转成模型输入JSON |
| `main` | 采集入口：按日期/单场拉取全盘口 |

## fetch_sporttery_history.py

| 函数名 | 中文功能 |
| --- | --- |
| `atomic` | 原子写JSON文件 |
| `get` | 带重试的HTTP GET |
| `keep` | 联赛过滤：只保留五大联赛与杯赛 |
| `days` | 生成日期序列 |
| `flatten` | 展平场次列表 |
| `latest_before` | 取某时间前最近一次快照 |
| `odds` | 提取三项赔率 |
| `fixed` | 抓取单场固定奖金历史 |
| `main` | 下载指定区间历史数据 |
| `task` | 并发任务包装 |

## import_statsbomb_xg.py

| 函数名 | 中文功能 |
| --- | --- |
| `main` | 从StatsBomb仓库导入xG事件数据 |

## market_fit.py

| 函数名 | 中文功能 |
| --- | --- |
| `_parse_time` | 解析时间字符串（兼容Z时区后缀） |
| `market_freshness` | 计算各盘口相对开球时间的新鲜度 |
| `effective_market_weights` | 合并默认与输入的市场权重 |
| `devig` | 赔率去水（按选定方法） |
| `selected_method` | 读取输入指定的去水方法 |
| `total_probs` | 比分矩阵聚合成8档总进球概率 |
| `hhad_probs` | 由比分矩阵计算让球后三态概率 |
| `ou_probs` | 由比分矩阵计算大小球概率 |
| `hafu_probs` | 由半全场拆λ卷积计算九宫格概率 |
| `objective` | 多盘口联合拟合的损失函数 |
| `fit` | 多市场联合拟合λ（HAD+HHAD/O-U/TTG/HAFU） |

## merge_preview.py

| 函数名 | 中文功能 |
| --- | --- |
| `local_results` | 读取本地已结算比赛用于去重比对 |
| `norm_date` | 标准化日期为YYYY-MM-DD |
| `main` | 把官方前瞻合并进模型输入 |

## odds_methods.py

| 函数名 | 中文功能 |
| --- | --- |
| `_validate` | 校验赔率合法（有限且>1） |
| `proportional` | 比例去水（默认方法） |
| `additive` | 等额边际去水 |
| `power` | 幂方法去水（数值求解k） |
| `shin` | Shin模型去水（数值求解内幕份额z） |
| `probs` | Shin概率解析式（含数值保护分支） |
| `devig` | 按名称分发去水方法（含别名） |
| `available_methods` | 返回可用去水方法列表 |

## odds_movement.py

| 函数名 | 中文功能 |
| --- | --- |
| `read` | 按行读取赔率移动库jsonl |
| `devig` | 比例去水得到公平概率 |
| `_history` | 兼容两种采集器结构的盘口历史提取 |
| `_match_fields` | 从不同格式采集行提取比赛标识字段 |
| `collect` | 从采集原始JSON抽取全部盘口快照 |
| `main` | 赔率移动库子命令：add/show/drift |

## predict.py

| 函数名 | 中文功能 |
| --- | --- |
| `league_calibration` | 按比赛识别联赛并返回对应校准参数 |
| `calibrate_1x2` | 对胜平负概率施加平局修正+温度缩放 |
| `star_rating` | 由最大概率映射星级（含实测命中率与样本量） |
| `_platt` | Platt校准变换（logit回归映射） |
| `clamp` | 把数值限制在[lo,hi]区间 |
| `pmf` | 泊松概率质量函数（尾部并入最后一格） |
| `matrix` | 独立泊松+Dixon-Coles低比分修正生成比分矩阵 |
| `one` | 比分矩阵聚合为胜平负三元概率 |
| `audit_lambda_and_clean_sheet` | 审计极端λ与零封概率（只提示不修改） |
| `devig` | 赔率去水（默认比例法，其他方法显式启用） |
| `selected_devig_method` | 读取并校验输入指定的去水方法 |
| `market_lam_heuristic` | 旧版线性λ映射（反解失败时的兜底） |
| `solve_lam_from_probs` | 反解λ：还原市场1X2概率的λ对 |
| `market_lam` | 由市场概率求λ（优先反解，失败回退线性映射） |
| `elo_lam` | 由Elo差值反推双方λ |
| `resolve_goal_total` | 确定场均总进球：显式>赛事查表>全局兜底 |
| `top` | 取概率最高的前n个比分 |
| `ou` | 由比分矩阵计算大小球（含走盘） |
| `settle` | 按让球线结算主胜/平/负三态概率 |
| `hhad_three_way` | 体彩让球胜平负三态（区别于亚洲盘） |
| `ah` | 亚洲盘结算（整数/半球/四分之一盘） |
| `validate` | 校验输入必填字段与强度锚 |
| `quality` | 计算输入完整度/来源/新鲜度质量分 |
| `advancement` | 双回合晋级路径模拟（90分钟/加时/点球） |
| `apply_fact_adjustments` | 在基础λ上应用伤停/战意/环境等事实修正 |
| `build_lambdas` | 综合市场/Elo/显式λ构建最终λ对 |
| `sensitivity` | λ±10%扰动下的概率敏感性传导 |
| `predict` | 单场预测主函数（校验→建模→输出） |
| `main` | 核心预测引擎CLI入口 |
| `probs` | 由总分与差值生成λ对候选 |
| `fit_diff` | 固定总分二分差值使主客概率命中目标 |

## record_prediction.py

| 函数名 | 中文功能 |
| --- | --- |
| `parse_dt` | 解析ISO时间字符串 |
| `main` | 把核心预测登记进回测库 |

## settle_from_sporttery.py

| 函数名 | 中文功能 |
| --- | --- |
| `norm` | 队名归一化（去掉FC/队/俱乐部等噪声） |
| `similar` | 中文简称相似判断（子串匹配） |
| `fetch_results` | 调用官方赛果接口并返回结果列表 |
| `fetch_results_multi` | 按日期逐日拉取赛果并合并去重 |
| `main` | 按官方赛果自动回填登记库 |

## settle_result.py

| 函数名 | 中文功能 |
| --- | --- |
| `score` | 把'主-客'比分字符串转成整数元组 |
| `main` | 为单场登记写入赛果 |

## time_decay.py

| 函数名 | 中文功能 |
| --- | --- |
| `parse_score` | 从多种结构解析比分 |
| `parse_dt` | 解析时间字符串 |
| `_row_score_for_team` | 取指定球队在一行赛果中的进失球 |
| `decayed_team_rates` | 按半衰期衰减计算球队近期攻防速率 |
| `build_decay_strength` | 用两队近期衰减均值交叉生成λ候选 |

## xg_store.py

| 函数名 | 中文功能 |
| --- | --- |
| `norm` | 标准化队名（去空格非字母数字） |
| `key` | 生成比赛去重键 |
| `rid` | 生成记录稳定哈希ID |
| `read` | 读取jsonl记录 |
| `main` | xG库子命令：add/aggregate |
